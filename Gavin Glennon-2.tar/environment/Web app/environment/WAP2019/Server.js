var express = require('express')
var path = require('path');
const cors = require('cors')

app.get('/',function(req,res){
    res.sendfile(path.join(__dirname+'/index.html'));
});